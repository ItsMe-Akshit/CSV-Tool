# CSV Column Summary Tool
Run: `python backend/server.py` then open http://127.0.0.1:8000
- backend/server.py : REST API, analysis engine, JSON persistence (stdlib only)
- frontend/ : index.html, style.css, app.js
- Optional: pip install matplotlib for PNG charts

## Demo UI (Streamlit)
```
pip install -r requirements.txt
streamlit run streamlit_app.py
```
- `streamlit_app.py` : Streamlit interface (upload, overview, column summary, search, charts, import log, export)
- `ui_helpers.py`    : UI-independent helpers; reuses the analysis engine in `server.py`
