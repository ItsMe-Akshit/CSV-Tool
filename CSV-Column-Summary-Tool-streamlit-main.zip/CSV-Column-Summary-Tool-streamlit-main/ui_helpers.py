"""Pure-Python helpers shared by the demo UI (no Streamlit import -> easy to test).

Reuses the original engine in server.py (parse_csv, analyse, search, export),
so the UI and the REST API always give identical results.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "backend")):      # works for flat or backend/ layout
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)

import server  # noqa: E402  (original engine)

SAMPLE_CANDIDATES = [
    os.path.join(HERE, "students_sample.csv"),
    os.path.join(HERE, "sample_data", "students_sample.csv"),
]


def decode_bytes(raw: bytes) -> str:
    """Decode uploaded bytes; fall back to latin-1 so odd files never crash."""
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def load_sample_text():
    for p in SAMPLE_CANDIDATES:
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                return f.read()
    return None


def add_csv(db: dict, name: str, text: str) -> str:
    """Parse + store a dataset in the given dict. Raises ValueError on bad input."""
    return server.add_dataset(db, name, text)


def column_table(summary: dict) -> list[dict]:
    """One flat row per column for the 'Column Summary' table."""
    rows = []
    for c in summary["columns"]:
        s = c.get("stats", {})
        rows.append({
            "Column": c["name"], "Type": c["type"],
            "Missing": c["missing"], "Missing %": c["missing_pct"], "Unique": c["unique"],
            "Min": s.get("min"), "Max": s.get("max"), "Mean": s.get("mean"),
            "Median": s.get("median"), "Std": s.get("std"),
            "Q1": s.get("q1"), "Q3": s.get("q3"), "Outliers": s.get("outliers"),
            "Flags": "; ".join(c["warnings"]),
        })
    return rows


def histogram_points(col: dict):
    """(bin_centre, count) pairs for a numeric column's histogram."""
    h = col["stats"]["hist"]
    lo, hi = col["stats"]["hist_range"]
    w = (hi - lo) / len(h) if hi > lo else 1
    return [(round(lo + w * (i + 0.5), 4), n) for i, n in enumerate(h)]


# ------------------------------------------------------------------ persistence
import json  # noqa: E402

DATA_DIR = os.path.join(HERE, "data")
DB_FILE = os.path.join(DATA_DIR, "datasets.json")


def load_db() -> dict:
    """Load saved datasets from data/datasets.json (empty dict if missing/corrupt)."""
    try:
        with open(DB_FILE, encoding="utf-8") as f:
            db = json.load(f)
        return db if isinstance(db, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def save_db(db: dict) -> None:
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(db, f)
    os.replace(tmp, DB_FILE)  # atomic write


# ------------------------------------------------------------------ friendly text
SAMPLE_NAME = "students_sample.csv"

TYPE_HELP = {
    "integer": "Whole numbers (e.g. 18, 1001)",
    "float": "Decimal numbers (e.g. 8.69)",
    "text": "Words / labels (e.g. CSE, emails)",
    "date": "Dates (e.g. 2024-04-05)",
    "boolean": "Yes / No or True / False",
    "mixed": "Mostly numbers, but some bad values mixed in",
    "empty": "No values at all",
}


def ensure_sample(db: dict):
    """Make sure the sample dataset is in db. Returns its id, or None if the file is missing."""
    for did, d in db.items():
        if d["name"] == SAMPLE_NAME:
            return did
    text = load_sample_text()
    if text is None:
        return None
    return add_csv(db, SAMPLE_NAME, text)


def quality_label(completeness: float):
    """(label, emoji) describing how complete the data is."""
    if completeness >= 98:
        return "Excellent", "🟢"
    if completeness >= 90:
        return "Good", "🟡"
    if completeness >= 75:
        return "Fair", "🟠"
    return "Needs cleaning", "🔴"


def plain_summary(s: dict) -> list[str]:
    """Plain-English bullet points describing a dataset summary."""
    out = [f"This file has **{s['rows']} rows** (records) and **{s['cols']} columns** (fields)."]
    label, emoji = quality_label(s["completeness"])
    out.append(f"{emoji} Data completeness is **{s['completeness']}% – {label}**. "
               f"{s['missing_total']} cell(s) are empty or marked N/A.")
    gaps = sorted((c for c in s["columns"] if c["missing"]), key=lambda c: -c["missing"])
    if gaps:
        out.append("Columns with the most gaps: " +
                   ", ".join(f"**{c['name']}** ({c['missing']})" for c in gaps[:3]) + ".")
    nums = [c["name"] for c in s["columns"] if "stats" in c]
    if nums:
        out.append("Numeric columns (have min / max / average): " + ", ".join(f"**{n}**" for n in nums) + ".")
    out.append(f"Duplicate rows found: **{s['duplicates']}**." if s["duplicates"]
               else "No duplicate rows found.")
    if s["errors"]:
        out.append(f"**{len(s['errors'])} row(s)** had format problems during import – see the *Import Log* tab.")
    return out
