"""
CSV Column Summary Tool - Streamlit demo interface
Run:  python -m streamlit run streamlit_app.py
"""
import pandas as pd
import streamlit as st

import ui_helpers as H

server = H.server

st.set_page_config(page_title="CSV Column Summary Tool", page_icon="📊", layout="wide")

st.markdown("""
<style>
div[data-testid="stMetric"] {border:1px solid rgba(128,128,128,.25); border-radius:12px;
    padding:14px 16px; background:rgba(99,102,241,.06);}
div[data-testid="stMetricValue"] {font-size:1.9rem;}
.block-container {padding-top:2.2rem;}
</style>
""", unsafe_allow_html=True)

# ----------------------------------------------------------------- session
if "db" not in st.session_state:
    st.session_state.db = H.load_db()          # saved datasets survive restarts
    st.session_state.seen = set()
    st.session_state.current = None
    if not st.session_state.db:                # first run: open the sample automatically
        sid = H.ensure_sample(st.session_state.db)
        if sid:
            H.save_db(st.session_state.db)
            st.session_state.current = sid
    elif st.session_state.db:
        st.session_state.current = next(iter(st.session_state.db))

db = st.session_state.db


def open_sample():
    sid = H.ensure_sample(db)
    if sid is None:
        st.error("students_sample.csv was not found next to streamlit_app.py.")
        return
    H.save_db(db)
    st.session_state.current = sid
    st.rerun()


# ----------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("📁 Datasets")
    up = st.file_uploader("Upload your own CSV / TSV / TXT", type=["csv", "tsv", "txt"])
    if up is not None:
        key = (up.name, up.size)
        if key not in st.session_state.seen:
            st.session_state.seen.add(key)
            if up.size > server.MAX_BYTES:
                st.error(f"File too large (max {server.MAX_BYTES // 1048576} MB)")
            else:
                try:
                    did = H.add_csv(db, up.name, H.decode_bytes(up.getvalue()))
                    H.save_db(db)
                    st.session_state.current = did
                    n = len(db[did]["errors"])
                    st.success("Imported" + (f" with {n} row issue(s) logged" if n else " successfully"))
                except ValueError as e:
                    st.error(str(e))

    if st.button("📘 Open sample (students_sample.csv, 42 rows)", use_container_width=True):
        open_sample()

    st.subheader("Saved datasets")
    if st.session_state.current not in db:
        st.session_state.current = next(iter(db), None)
    if not db:
        st.caption("No datasets yet")
    for did, d in list(db.items()):
        active = did == st.session_state.current
        with st.container(border=True):
            c_open, c_del = st.columns([5, 1])
            if c_open.button(("📂 " if active else "📄 ") + d["name"], key=f"open_{did}",
                             type="primary" if active else "secondary", use_container_width=True):
                st.session_state.current = did
                st.rerun()
            if c_del.button("✕", key=f"del_{did}", help="Delete this dataset"):
                del db[did]
                H.save_db(db)
                st.rerun()
            st.caption(f"{len(d['rows'])} rows · {len(d['columns'])} cols · {d['uploaded']}")

# ----------------------------------------------------------------- header
st.title("📊 CSV Column Summary Tool")
st.caption("Upload a CSV file and instantly see every column's type, missing values and statistics.")

if not db or st.session_state.current is None:
    st.info("**Welcome!** Upload a CSV from the sidebar, or try the built-in sample.")
    if st.button("📘 Open sample dataset (students_sample.csv – 42 rows)", type="primary"):
        open_sample()
    st.stop()

ds = db[st.session_state.current]
s = server.analyse(ds)

st.markdown(f"#### Now viewing: `{s['name']}` — {s['rows']} rows × {s['cols']} columns")

tabs = st.tabs(["🏠 Overview", "📋 Column Summary", f"📄 All Data ({s['rows']} rows)", "🔎 Search Records",
                "📈 Charts", f"🧾 Import Log ({len(s['errors'])})", "⬇ Export"])

# ----------------------------------------------------------------- overview
with tabs[0]:
    k = st.columns(6)
    k[0].metric("Rows", s["rows"], help="Number of data records (header row not counted).")
    k[1].metric("Columns", s["cols"], help="Number of fields in each record.")
    k[2].metric("Numeric columns", s["numeric_cols"], help="Columns that contain numbers.")
    k[3].metric("Missing cells", s["missing_total"], help="Empty cells or values like N/A, null, -, ?")
    label, emoji = H.quality_label(s["completeness"])
    k[4].metric("Completeness", f"{s['completeness']}%", help="Share of cells that are filled in.")
    k[5].metric("Duplicate rows", s["duplicates"], help="Rows that are exact copies of another row.")

    left, right = st.columns([3, 2], gap="large")
    with left:
        st.markdown("### 💡 What this file tells you")
        for line in H.plain_summary(s):
            st.markdown(f"- {line}")
        st.markdown("### 👀 First 10 rows")
        st.dataframe(pd.DataFrame(ds["rows"][:10], columns=ds["columns"]),
                     use_container_width=True, hide_index=True)
    with right:
        st.markdown(f"### ⚠ Things to check ({len(s['warnings'])})")
        if s["warnings"]:
            for w in s["warnings"]:
                st.warning(w, icon="⚠️")
        else:
            st.success("No issues detected", icon="✅")

# ----------------------------------------------------------------- columns
with tabs[1]:
    st.markdown("One row per column. **Missing %** shows how empty a column is; "
                "numeric columns also show min, max, average (mean), middle value (median) and spread (std).")
    table = pd.DataFrame(H.column_table(s))
    st.dataframe(
        table, use_container_width=True, hide_index=True,
        column_config={
            "Missing %": st.column_config.ProgressColumn("Missing %", min_value=0, max_value=100,
                                                         format="%.1f%%"),
            "Std": st.column_config.NumberColumn("Std", help="Standard deviation – how spread out values are"),
            "Q1": st.column_config.NumberColumn("Q1", help="25% of values are below this"),
            "Q3": st.column_config.NumberColumn("Q3", help="75% of values are below this"),
            "Outliers": st.column_config.NumberColumn("Outliers", help="Unusually high/low values (IQR rule)"),
        })
    with st.expander("What do the data types mean?"):
        for t, desc in H.TYPE_HELP.items():
            st.markdown(f"- **{t}** – {desc}")

# ----------------------------------------------------------------- all data
with tabs[2]:
    st.markdown(f"All **{s['rows']} rows** of the file. Empty cells are blank; scroll inside the table to see everything.")
    full = pd.DataFrame(ds["rows"], columns=ds["columns"])
    full.index = range(1, len(full) + 1)
    full.index.name = "Row #"
    st.dataframe(full, use_container_width=True, height=600)

# ----------------------------------------------------------------- search
with tabs[3]:
    st.markdown("Look for specific rows. Leave the keyword empty to browse everything.")
    c1, c2, c3 = st.columns([3, 2, 2])
    q = c1.text_input("Keyword", placeholder="e.g. CSE")
    col = c2.selectbox("Search in", [""] + ds["columns"], format_func=lambda x: x or "All columns")
    miss_only = c3.checkbox("Only rows with missing values")
    r = server.search(ds, q, col, miss_only, 1)
    page = 1
    if r["pages"] > 1:
        page = st.number_input("Page", min_value=1, max_value=r["pages"], value=1, step=1)
        r = server.search(ds, q, col, miss_only, int(page))
    st.write(f"**{r['total']}** matching row(s) — page {r['page']} of {r['pages']}")
    st.dataframe(pd.DataFrame(r["rows"], columns=["Row #"] + r["columns"]),
                 use_container_width=True, hide_index=True)

# ----------------------------------------------------------------- charts
with tabs[4]:
    name = st.selectbox("Choose a column to chart", [c["name"] for c in s["columns"]])
    c = next(x for x in s["columns"] if x["name"] == name)
    if "stats" in c:
        a, b, d_ = st.columns(3)
        a.metric("Average (mean)", c["stats"]["mean"])
        b.metric("Middle (median)", c["stats"]["median"])
        d_.metric("Range", f"{c['stats']['min']} – {c['stats']['max']}")
        st.caption("Histogram: how many rows fall into each value range.")
        st.bar_chart(pd.DataFrame(H.histogram_points(c), columns=[name, "rows"]).set_index(name))
    elif c.get("top"):
        st.caption("Most common values in this column.")
        st.bar_chart(pd.DataFrame(c["top"], columns=[name, "rows"]).set_index(name))
    else:
        st.info("Nothing to chart for this column.")

# ----------------------------------------------------------------- log
with tabs[5]:
    if s["errors"]:
        st.caption("Rows the importer had to fix or skip (line 1 is the header).")
        st.dataframe(pd.DataFrame(s["errors"]).rename(columns={"row": "Line", "issue": "Issue"}),
                     use_container_width=True, hide_index=True)
    else:
        st.success("Every row imported cleanly.")

# ----------------------------------------------------------------- export
with tabs[6]:
    st.write("Download the summary report in your preferred format:")
    labels = {"md": "Markdown report", "txt": "Plain text", "csv": "CSV table", "json": "JSON data"}
    cols = st.columns(4)
    for slot, fmt in zip(cols, labels):
        body, mime, ext = server.export(ds, fmt)
        slot.download_button(f"⬇ {labels[fmt]}", body, file_name=f"summary.{ext}", mime=mime,
                             use_container_width=True)
